package com.company.Entities;

public interface Discountable {
    public String getId();
    public Discountable getParent();
}
