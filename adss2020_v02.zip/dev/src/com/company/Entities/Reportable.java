package com.company.Entities;

public interface Reportable {
    public String getId();

}
